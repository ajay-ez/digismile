import { AddMedicalRecords } from "@/features/add-medical-records";
import React from "react";

const AddMedicalRecordsPage = () => {
  return (
    <div>
      <AddMedicalRecords />
    </div>
  );
};

export default AddMedicalRecordsPage;
