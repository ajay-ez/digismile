import { ProfileFeature } from '@/features/profile/ProfileFeature';
import React from 'react';

const Profile = () => {
  return (
    <div>
      <ProfileFeature />
    </div>
  );
};

export default Profile;
