export default {
  0: "0",
  "0.5": "0.5px",
  1: "1px",
  2: "0.125rem", // 2px
  3: "0.188rem", // 3px
  4: "0.25rem", // 4px
};
