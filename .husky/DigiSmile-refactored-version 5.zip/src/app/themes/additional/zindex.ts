export default {
  body: 1,
  tableStickyHeaders: 2,
  sidebar: 4,
  modal: 99,
  toaster: 5,
};
