export default {
  baseStyle: {},
  variants: {},
  sizes: {},
};
