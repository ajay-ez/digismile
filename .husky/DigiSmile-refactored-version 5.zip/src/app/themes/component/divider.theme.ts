export default {
  baseStyle: {
    borderColor: "brand.100",
    opacity: "1",
  },
  variants: {},
  sizes: {},
};
