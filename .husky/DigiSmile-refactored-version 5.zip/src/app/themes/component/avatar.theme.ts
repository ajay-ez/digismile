export default {
  baseStyle: {},
  variants: {
    editor: {
      badge: {},
      container: {},
      excessLabel: {},
      group: {},
    },
  },
  sizes: {},
};
