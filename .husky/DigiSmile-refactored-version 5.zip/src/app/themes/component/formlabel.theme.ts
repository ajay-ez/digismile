export default {
  baseStyle: {
    fontSize: "sm",
  },
  variants: {},
};
