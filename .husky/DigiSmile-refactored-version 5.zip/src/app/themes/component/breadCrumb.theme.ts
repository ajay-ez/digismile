export default {
  baseStyle: {
    link: {
      fontSize: "sm",
    },
    item: {},
    container: {},
    seperator: {},
  },
  variants: {},
  sizes: {},
};
