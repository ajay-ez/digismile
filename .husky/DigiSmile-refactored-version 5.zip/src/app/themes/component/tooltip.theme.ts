export default {
  baseStyle: {
    zIndex: 1,
  },
  variants: {},
  sizes: {},
};
