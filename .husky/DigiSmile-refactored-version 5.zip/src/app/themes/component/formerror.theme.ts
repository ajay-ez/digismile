export default {
  baseStyle: {
    text: {
      fontSize: "xs",
      color: "red.500",
    },
  },
  variants: {},
};
