"use client";
import React from "react";
import LandingPage from "@/features/LandingPage/LandingPage";

const HomePage: React.FC = () => {
  return <LandingPage />;
};

export default HomePage;
