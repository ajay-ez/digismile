export const city = [
  {
    label: "Burke,VA",
    value: "burke"
  },
  {
    label: "Washington D.C.",
    value: "dc"
  }
];
