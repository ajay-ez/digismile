import React from 'react';

import { Tabs } from './Tabs/Tabs';

export const ProfileFeature = () => {
  return (
    <div>
      <Tabs />
    </div>
  );
};
